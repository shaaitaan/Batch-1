package com.cognizant.bindings;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Customer {
 @XmlElement(name = "cid")	
 private Integer customerId;
 
 @XmlElement(name = "cname")
 private String customerName;
 
 @XmlElement(name = "email")
 private String customerEmail;
}
