package com.cognizant.bindings;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement
public class Customer {
  private Integer cid;
  private String name;
  private String email;
}
