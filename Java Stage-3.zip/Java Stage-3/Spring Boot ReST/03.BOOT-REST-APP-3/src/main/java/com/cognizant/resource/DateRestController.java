package com.cognizant.resource;

import java.util.Calendar;
import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.util.ClassUtil.Ctor;

@RestController
public class DateRestController {
 @GetMapping("/welcome")	
 public String welcomeMessage() {
	 String msg = "Welcome to Cognizant";
	 try {
		 Thread.sleep(5000);
	 }catch(Exception ex) {}
	 
	 return msg;
 }
 
 @GetMapping("/date")
 public Date getDate() {
	Date d = new Date();
	return d;
 }
 
 @GetMapping("/today")
 public String getToday() {
	 Calendar cal = Calendar.getInstance();
	 Date today = cal.getTime();
	 String responseMsg = "Today is : "+ today;
	 return responseMsg;
 }
 
 @GetMapping("/response")
 public ResponseEntity<String> sendResponse(){
	 //ResponseEntity<String> resEntity = new ResponseEntity<>("Welcome to Cognizant", HttpStatus.OK);
	 //ResponseEntity<String> resEntity = new ResponseEntity<>("Welcome to Cognizant", HttpStatus.CREATED);
	 //ResponseEntity<String> resEntity = new ResponseEntity<>("Welcome to Cognizant", HttpStatus.BAD_REQUEST);
	 
	 /*--to include response headers with ResponseEntity----*/
	 HttpHeaders headers = new HttpHeaders();
	 headers.add("my-header", "my-value");
	 
	 ResponseEntity<String> resEntity = new ResponseEntity<>("Welcome to Cognizant",headers ,HttpStatus.OK);
	 return resEntity;
 }
 
 //@GetMapping("/head")
 @PostMapping("/head")
 public ResponseEntity<String> readHeads(@RequestHeader(name = "dept", required = false, defaultValue = "NA") String dept, @RequestHeader("Content-Type") String ctype, @RequestBody String reqBody){
	 String response = "Department : "+dept+" || Content-Type : "+ctype+" || Message Body : "+reqBody;
	 return new ResponseEntity<>(response, HttpStatus.OK);
 }
}
