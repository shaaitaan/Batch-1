package com.cognizant.controller;

import java.util.Calendar;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController                                 
@RequestMapping("/personal")
public class AgeRestController {
	@GetMapping("/age/{name}/{yob}")
	public ResponseEntity<String> getAge(@PathVariable String name, @PathVariable("yob") Integer yob) {
		if (isYearOfBirthValid(yob)) {
			int age = calculateAge(yob);
			ResponseEntity<String> resEntity = new ResponseEntity<>(name+"'s Age is " + age, HttpStatus.OK);
			return resEntity;
		}
		return new ResponseEntity<>(name+", Year of Birth should not be in Future, You given as " + yob,
				HttpStatus.BAD_REQUEST);		
	}

	private int calculateAge(int yob) {
		// get the current year
		Calendar cal = Calendar.getInstance();
		int currentYear = cal.get(Calendar.YEAR);
		return currentYear-yob;
	}

	private boolean isYearOfBirthValid(int yob) {
		// get the current year
		Calendar cal = Calendar.getInstance();
		int currentYear = cal.get(Calendar.YEAR);
		return currentYear > yob;
	}
}
