package com.cognizant.controller;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.request.bindings.PassengerInfo;
import com.cognizant.response.bindings.TicketInfo;

@RestController
@RequestMapping("/ticket")
public class TicketBookingRestController {
 @PostMapping(
		   value = "/bookticket",
		   consumes = {"application/json","application/xml"},
		   produces = {"application/json","application/xml"}
		 )	
 public ResponseEntity<TicketInfo> bookTicket(@RequestBody PassengerInfo passenger){
	 System.out.println(passenger);
	 //logic to check the ticket availability and do the ticket booking
	 
	 TicketInfo tinfo = new TicketInfo();
	 tinfo.setTicketId(8574857L);
	 tinfo.setTicketStatus("CONFIRMED");
	 tinfo.setTicketPrice(1250.5f);
	 tinfo.setFrom(passenger.getFrom());
	 tinfo.setTo(passenger.getTo());
	 tinfo.setBookeddate(new Date().toString());
	 tinfo.setDoj(passenger.getDoj());
	 tinfo.setName(passenger.getName());
	 ResponseEntity<TicketInfo> response = new ResponseEntity<TicketInfo>(tinfo, HttpStatus.CREATED);
	 return response;
 }
}
