package com.cognizant.response.bindings;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement
public class TicketInfo {
 private Long ticketId;
 private String ticketStatus;
 private Float ticketPrice;
 private String from;
 private String to;
 private String bookeddate;
 private String name;
 private String doj;
}
